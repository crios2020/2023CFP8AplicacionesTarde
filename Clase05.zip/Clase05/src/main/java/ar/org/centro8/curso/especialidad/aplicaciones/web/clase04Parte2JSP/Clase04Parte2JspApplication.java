package ar.org.centro8.curso.especialidad.aplicaciones.web.clase04Parte2JSP;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Clase04Parte2JspApplication {

	public static void main(String[] args) {
		SpringApplication.run(Clase04Parte2JspApplication.class, args);
	}

}
