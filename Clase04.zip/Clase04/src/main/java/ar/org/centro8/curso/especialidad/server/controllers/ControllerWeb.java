package ar.org.centro8.curso.especialidad.server.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class ControllerWeb {

    @GetMapping("/")
    public String getIndex(){
        return "index";
    }

    @GetMapping("/sumarForm")
    public String getSumar(){
        return "sumarForm";
    }

    @GetMapping("/calculadoraForm")
    public String getCalculadora(){
        return "calculadoraForm";
    }

}
