package ar.org.centro8.curso.especialidad.server.test;

import java.math.BigDecimal;

public class TestFlotante {
    public static void main(String[] args) {
        BigDecimal bg=new BigDecimal(0);
        String texto="Hola";
        
        //int tipo de datos entero 32 bits
        int nro=3;

        //long tipo de datos entero 64 bits
        long nrox=6000L;

        //Tipo de datos float 32 bits
        float fl=7.65f;
        System.out.println(fl);

        //Tipo de datos double 64 bits
        double dl=7.65;
        System.out.println(dl);


        fl=10;
        dl=10;

        System.out.println(fl/3);
        System.out.println(dl/3);

        fl=100;
        dl=100;

        System.out.println(fl/3);
        System.out.println(dl/3);

        fl=1000;
        dl=1000;

        System.out.println(fl/3);
        System.out.println(dl/3);

        double nroxd=Double.parseDouble("step=\".000001\" ");



    }
}
